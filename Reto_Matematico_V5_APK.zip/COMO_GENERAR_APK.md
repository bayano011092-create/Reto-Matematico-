# Cómo generar el APK desde el celular

1. Crea una cuenta/repositorio en GitHub.
2. Crea un repositorio nuevo llamado `Reto-Matematico`.
3. Sube TODO el contenido de esta carpeta manteniendo las carpetas.
4. En GitHub abre la pestaña **Actions**.
5. Selecciona **Generar APK**.
6. Pulsa **Run workflow**.
7. Espera a que termine la compilación.
8. En la ejecución terminada, busca **Artifacts**.
9. Descarga `Reto-Matematico-debug-apk`.
10. Dentro estará `app-debug.apk`.

No necesitas instalar Android Studio en el teléfono para este método.

Si GitHub muestra un error de compilación, no borres el proyecto: copia aquí el mensaje rojo del error y lo corregimos.
