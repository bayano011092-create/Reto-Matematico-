# Reto Matemático V5 — Proyecto Android

Esta versión toma el juego V4 y lo envuelve en una aplicación Android nativa mediante WebView.

Incluye:
- Juego V4 completo dentro de la app.
- Nombre de aplicación: Reto Matemático.
- Orientación vertical.
- Guardado local mediante localStorage.
- JavaScript y almacenamiento DOM habilitados.
- Estructura Android Gradle estándar.
- Application ID: com.retomatematico.app
- Version 1.0.0 / versionCode 5.

## Generar APK
Abre esta carpeta como proyecto en Android Studio y ejecuta:
Build > Build APK(s)

El APK de depuración normalmente aparecerá en:
app/build/outputs/apk/debug/app-debug.apk

Nota: este entorno no dispone de un Android SDK/Gradle instalado, por lo que aquí se entrega el proyecto Android listo para compilar, no un APK ya compilado.
